IRL Pro HUD + YouTube Chat — AUTO FIX

Esta versão mantém o HUD e o chat e tenta primeiro a live-semente atual.
Depois que ela terminar, usa o canal descoberto para procurar automaticamente a próxima live.

No GitHub Pages, a URL fica fixa, sem ?video=:
https://lucasalvesla248-commits.github.io/Overlays-youtube/

A chave da YouTube Data API fica salva no navegador/WebView. Não compartilhe a chave.
