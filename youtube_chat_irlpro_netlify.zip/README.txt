# YouTube Chat Overlay — IRL Pro

Overlay transparente, com mensagens do chat do YouTube em tempo real para usar como Browser/Web Overlay no IRL Pro.

## 1) Criar a chave da API
No Google Cloud:
1. Crie/selecione um projeto.
2. Ative **YouTube Data API v3**.
3. Crie uma **API key**.
4. Recomenda-se restringir a chave por HTTP referrer depois de colocar o overlay em um domínio Netlify.

## 2) Colocar no Netlify
Envie o arquivo `youtube-chat-irlpro.html` para um site estático no Netlify.

Abra a página uma vez no navegador, informe:
- API Key
- URL/ID da live do YouTube

Ela salva a configuração no navegador.

## 3) Usar no IRL Pro
Como Browser/Web Overlay, use a URL do arquivo hospedado.

Exemplo:
https://SEU-SITE.netlify.app/youtube-chat-irlpro.html

Também dá para deixar a configuração diretamente na URL:
https://SEU-SITE.netlify.app/youtube-chat-irlpro.html?key=SUA_API_KEY&video=ID_DA_LIVE

A chave da API ficará visível no cliente. Por segurança, use restrição de referrer/uso adequada no Google Cloud.

## Visual
- Fundo 100% transparente
- YouTube vermelho + triângulo branco
- Nome colorido
- Mensagem branca em negrito
- Até 8 mensagens na tela
- Mensagens antigas desaparecem
- Atualização respeitando o intervalo recomendado pelo YouTube
